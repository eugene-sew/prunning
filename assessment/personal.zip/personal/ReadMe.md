# Todo App Exercise

In this exercise, you will be building your own todo list application using JavaScript and HTML. The goal of this exercise is to practice your front-end development skills, as well as your ability to work with arrays and basic DOM manipulation.

## Building Your Todo App

Your todo app should allow users to:

- Add new tasks to the list
- Mark tasks as completed
- Delete tasks from the list

You should start by implementing the functionality to add new tasks to the list. Once that is working, you can move on to adding the ability to mark tasks as completed and delete tasks from the list.

## Adding Delete Functionality

To add delete functionality, you should add a button next to each task in the list that allows the user to delete that task. When the user clicks the button, the task should be removed from the list.

## Submitting Your Work

You will be provided with a submission link later, where you can submit the link to your compressed solution.

Good luck!
