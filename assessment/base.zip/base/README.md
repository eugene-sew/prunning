# TODO App Exercise

In this exercise, you will create a simple todo list application using JavaScript and HTML. The goal of this exercise is to practice your front-end development skills, as well as your ability to work with arrays and basic DOM manipulation.

## Watch the WATCHME video

Before you start, please watch the WATCHME video, which will provide you with an overview of the application you will be building and guide you through the setup process.

## Running the app

The basic functionality of the app has already been implemented for you. You can add items to the list by typing a task into the input field and clicking the "Add" button.

To run the app, simply open the `index.html` file in your web browser.

## Styling the app

Once you have the basic functionality working, you can work on styling the app to make it look better. You should only use CSS to style the app. Feel free to experiment with CSS and other front-end technologies to make the app look great.

## Submitting your work

You will be provided with a submission link later, where you can submit the compressed solution

Good luck!
